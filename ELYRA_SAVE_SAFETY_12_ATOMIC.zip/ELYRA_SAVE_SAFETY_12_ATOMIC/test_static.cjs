const fs=require('fs'),assert=require('assert'),vm=require('vm'),crypto=require('crypto');
const root=__dirname;const core=fs.readFileSync(root+'/savecore.atomic.js','utf8');const migration=fs.readFileSync(root+'/shadow-migration.atomic.js','utf8');const html=fs.readFileSync(root+'/test_atomic_browser.html','utf8');
const checks=[];function test(name,fn){try{fn();checks.push({name,result:'PASS'});}catch(e){checks.push({name,result:'FAIL',error:e.message});}}
test('core parses',()=>new vm.Script(core));
test('migration parses',()=>new vm.Script(migration));
test('browser embeds same core',()=>assert(html.includes(core)));
test('exclusive check and write share readwrite transaction',()=>{const body=core.slice(core.indexOf('function atomicImport'),core.indexOf('function allRecords'));assert(body.includes("db.transaction([SNAP,HEAD],'readwrite')"));assert(body.includes("openKeyCursor(IDBKeyRange.only(id))"));assert(body.includes('tx.abort()'));assert(body.includes('s.add('));});
test('migration uses exclusive import',()=>{assert(migration.includes('await core.importExclusive(lifeId,checked)'));assert(!migration.includes('await core.save(lifeId,checked)'));});
test('legacy import uses exclusive import',()=>assert(core.includes('return this.importExclusive(id,s)')));
test('lab uses separate database',()=>assert(core.includes('elyra_savecore_atomic12_lab')));
const r={passed:checks.filter(x=>x.result==='PASS').length,total:checks.length,checks};fs.writeFileSync(root+'/NODE_RESULTS.json',JSON.stringify(r,null,2));console.log(JSON.stringify(r,null,2));if(r.passed!==r.total)process.exitCode=1;
