/* ELYRA shadow migration 1.0 candidate. Isolated; does not read/write legacy localStorage. */
(function(root){'use strict';
const enc=new TextEncoder();
const digest=async text=>Array.from(new Uint8Array(await root.crypto.subtle.digest('SHA-256',enc.encode(text))),x=>x.toString(16).padStart(2,'0')).join('');
async function migrateShadow({lifeId,legacyJson,validateLegacy,core,occupied}){
 if(typeof lifeId!=='string'||!lifeId.trim()||lifeId.length>200)throw Error('Invalid life ID');
 if(typeof legacyJson!=='string'||!legacyJson.trim())throw Error('Missing legacy JSON');
 if(typeof validateLegacy!=='function')throw Error('Required engine.load validation callback missing');
 if(!core||typeof core.importExclusive!=='function'||typeof core.load!=='function'||typeof core.exportLife!=='function')throw Error('SaveCore required');
 // Occupancy is checked atomically by core.importExclusive, not in a separate preflight.
 // Engine validation MUST throw on invalid legacy payload; no implicit fallback to a new life.
 const checked=await validateLegacy(legacyJson);
 if(!checked||typeof checked!=='object'||Array.isArray(checked))throw Error('Legacy validator did not return world');
 if(checked.identity?.lifeId!==lifeId)throw Error('Legacy identity mismatch');
 // Never overwrite a life even if every existing snapshot is corrupt.
 
 const originalHash=await digest(legacyJson);
 const normalized=JSON.stringify(checked);
 if(!normalized)throw Error('Invalid normalized world');
 const result=await core.importExclusive(lifeId,checked);
 if(!result?.confirmed)throw Error('Save not confirmed');
 const readback=await core.load(lifeId);
 if(!readback||JSON.stringify(readback.state)!==normalized)throw Error('Shadow readback mismatch');
 const exported=await core.exportLife(lifeId);
 if(JSON.stringify(JSON.parse(exported))!==normalized)throw Error('Shadow export mismatch');
 return {confirmed:true,lifeId,revision:result.revision,originalSha256:originalHash,normalizedSha256:await digest(normalized),sourceBytes:enc.encode(legacyJson).length,originalPreserved:true};
}
// Raw occupancy is separate from core.load(), which intentionally skips corrupt records.
async function rawOccupied(dbName,lifeId){
 const db=await new Promise((resolve,reject)=>{const r=root.indexedDB.open(dbName);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.onupgradeneeded=()=>{r.transaction.abort();reject(Error('Missing SaveCore database'));};});
 try{return await new Promise((resolve,reject)=>{const tx=db.transaction(['snapshots','heads'],'readonly');const h=tx.objectStore('heads').get(lifeId);const s=tx.objectStore('snapshots').index('lifeId').getAllKeys(lifeId);let occupied=false;h.onsuccess=()=>{if(h.result)occupied=true;};s.onsuccess=()=>{if(s.result?.length)occupied=true;};tx.oncomplete=()=>resolve(occupied);tx.onabort=()=>reject(tx.error||Error('Occupancy check aborted'));});}finally{db.close();}
}
root.ELYRA_ShadowMigration={migrateShadow,rawOccupied};
})(globalThis);
