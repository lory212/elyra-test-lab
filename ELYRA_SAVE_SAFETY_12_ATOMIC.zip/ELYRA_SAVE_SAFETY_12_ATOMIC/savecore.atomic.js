/* ELYRA SaveCore 3.1 — isolated laboratory, not integrated with ELYRA. */
(function(global){'use strict';
const DB='elyra_savecore_atomic12_lab',VERSION=1,SNAP='snapshots',HEAD='heads';
const enc=new TextEncoder();
const hash=async s=>Array.from(new Uint8Array(await global.crypto.subtle.digest('SHA-256',enc.encode(s))),x=>x.toString(16).padStart(2,'0')).join('');
function lifeId(id){if(typeof id!=='string'||!id.trim()||id.length>200)throw Error('Invalid life ID');}
function validState(id,s){if(!s||typeof s!=='object'||Array.isArray(s)||s.identity?.lifeId!==id)throw Error('Invalid life identity');}
function open(){return new Promise((ok,no)=>{if(!global.indexedDB)return no(Error('IndexedDB unavailable'));const r=global.indexedDB.open(DB,VERSION);r.onupgradeneeded=()=>{let db=r.result;if(!db.objectStoreNames.contains(SNAP)){let s=db.createObjectStore(SNAP,{keyPath:'id'});s.createIndex('lifeId','lifeId',{unique:false});}if(!db.objectStoreNames.contains(HEAD))db.createObjectStore(HEAD,{keyPath:'lifeId'});};r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error||Error('Open failed'));r.onblocked=()=>no(Error('Database upgrade blocked'));});}
function atomicWrite(db,id,json,digest){return new Promise((ok,no)=>{let tx;try{tx=db.transaction([SNAP,HEAD],'readwrite');}catch(e){return no(e);}let revision;const h=tx.objectStore(HEAD),s=tx.objectStore(SNAP);const r=h.get(id);r.onsuccess=()=>{revision=(r.result?.revision||0)+1;const record={id:id+'::'+String(revision).padStart(12,'0'),lifeId:id,revision,json,hash:digest,at:Date.now()};s.add(record);h.put({lifeId:id,revision});};tx.oncomplete=()=>ok(revision);tx.onabort=()=>no(tx.error||Error('Write aborted'));tx.onerror=()=>{};});}
// Exclusive import: occupancy check and snapshot insertion in ONE IndexedDB transaction.
// Checking only HEAD is insufficient: an orphaned/corrupt snapshot still reserves its ID.
function atomicImport(db,id,json,digest){return new Promise((ok,no)=>{
 let tx;try{tx=db.transaction([SNAP,HEAD],'readwrite');}catch(e){return no(e);}
 const h=tx.objectStore(HEAD),s=tx.objectStore(SNAP);
 let revision=1, rejected=false;
 const head=h.get(id), existing=s.index('lifeId').openKeyCursor(IDBKeyRange.only(id));
 let headPresent=false,snapshotPresent=false,checks=0;
 function checked(){if(++checks!==2)return;
  if(headPresent||snapshotPresent){rejected=true;try{tx.abort();}catch{}return;}
  s.add({id:id+'::000000000001',lifeId:id,revision,json,hash:digest,at:Date.now()});
  h.add({lifeId:id,revision});
 }
 head.onsuccess=()=>{headPresent=!!head.result;checked();};
 existing.onsuccess=()=>{snapshotPresent=!!existing.result;checked();};
 tx.oncomplete=()=>ok(revision);
 tx.onabort=()=>no(rejected?Error('Life ID already occupied; import refused'):(tx.error||Error('Import aborted')));
 tx.onerror=()=>{};
 });}
function allRecords(db,id){return new Promise((ok,no)=>{const tx=db.transaction(SNAP,'readonly'),r=tx.objectStore(SNAP).index('lifeId').getAll(id);let out;r.onsuccess=()=>{out=r.result;};tx.oncomplete=()=>ok((out||[]).sort((a,b)=>b.revision-a.revision));tx.onabort=()=>no(tx.error||Error('Read aborted'));});}
function exactRecord(db,id,revision){return new Promise((ok,no)=>{const tx=db.transaction(SNAP,'readonly'),r=tx.objectStore(SNAP).get(id+'::'+String(revision).padStart(12,'0'));let record;r.onsuccess=()=>{record=r.result;};tx.oncomplete=()=>ok(record);tx.onabort=()=>no(tx.error||Error('Read aborted'));});}
async function verify(id,r){if(!r||r.lifeId!==id||typeof r.json!=='string'||typeof r.hash!=='string'||await hash(r.json)!==r.hash)return null;try{let state=JSON.parse(r.json);validState(id,state);return {revision:r.revision,state};}catch{return null;}}
class SaveCore{
 constructor(){this.queues=new Map();}
 async save(id,state){
  lifeId(id);validState(id,state);
  // Snapshot synchronously before joining the asynchronous queue.
  // Never allow caller mutations to change the payload after save() is requested.
  const snapshot=JSON.stringify(state);
  if(typeof snapshot!=='string')throw Error('State serialization failed');
  const parsed=JSON.parse(snapshot);
  validState(id,parsed);
  const previous=this.queues.get(id)||Promise.resolve();
  const task=previous.catch(()=>{}).then(()=>this._saveSnapshot(id,snapshot));
  this.queues.set(id,task);
  try{return await task;}finally{if(this.queues.get(id)===task)this.queues.delete(id);}
 }
 async _saveSnapshot(id,json){lifeId(id);const digest=await hash(json),db=await open();let revision;try{revision=await atomicWrite(db,id,json,digest);const record=await exactRecord(db,id,revision);const verified=await verify(id,record);if(!verified||record.json!==json)throw Error('Readback verification failed');return {confirmed:true,revision,hash:digest};}finally{db.close();}}
 async importExclusive(id,state){
  lifeId(id);validState(id,state);
  const snapshot=JSON.stringify(state);if(typeof snapshot!=='string')throw Error('Serialization failed');
  validState(id,JSON.parse(snapshot));
  const previous=this.queues.get(id)||Promise.resolve();
  const task=previous.catch(()=>{}).then(async()=>{
   const digest=await hash(snapshot),db=await open();
   try{const revision=await atomicImport(db,id,snapshot,digest);
    const record=await exactRecord(db,id,revision),v=await verify(id,record);
    if(!v||record.json!==snapshot)throw Error('Exclusive import readback failed');
    return {confirmed:true,revision,hash:digest};
   }finally{db.close();}
  });
  this.queues.set(id,task);
  try{return await task;}finally{if(this.queues.get(id)===task)this.queues.delete(id);}
 }
 async load(id){lifeId(id);const db=await open();try{for(const r of await allRecords(db,id)){const v=await verify(id,r);if(v)return v;}return null;}finally{db.close();}}
 async list(){const db=await open();try{const ids=await new Promise((ok,no)=>{const tx=db.transaction(HEAD,'readonly'),r=tx.objectStore(HEAD).getAllKeys();let keys;r.onsuccess=()=>keys=r.result;tx.oncomplete=()=>ok(keys||[]);tx.onabort=()=>no(tx.error||Error('List aborted'));});const out=[];for(const id of ids){if((await allRecords(db,id)).length){let good=false;for(const r of await allRecords(db,id)){if(await verify(id,r)){good=true;break;}}if(good)out.push(id);}}return out;}finally{db.close();}}
 async exportLife(id){const v=await this.load(id);if(!v)throw Error('No verified save');return JSON.stringify(v.state);}
 async importLegacy(id,json){lifeId(id);const s=JSON.parse(json);validState(id,s);return this.importExclusive(id,s);}
}
global.ELYRA_SaveCore_Step31=new SaveCore();
})(globalThis);
