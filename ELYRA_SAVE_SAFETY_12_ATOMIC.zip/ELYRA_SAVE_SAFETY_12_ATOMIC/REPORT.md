# ELYRA Save Safety 1.2 — Importazione esclusiva (candidata isolata)

## Modifica
- Nuovo `SaveCore.importExclusive(lifeId, state)`.
- Verifica occupazione (head oppure qualunque snapshot, anche corrotto) e inserimento in **una transazione IndexedDB readwrite** su `heads` e `snapshots`.
- L'importazione viene rifiutata se trova un ID occupato, senza sovrascrivere snapshot esistenti.
- La migrazione shadow chiama `importExclusive` invece della sequenza non atomica `occupied()` poi `save()`.
- Database del laboratorio dedicato: `elyra_savecore_atomic12_lab`; ELYRA 0.17 originale invariato.

## Test eseguiti
7/7 controlli Node.js di sintassi e struttura **PASS**. Questi NON sono test di transazioni IndexedDB reali. `test_atomic_browser.html` incorpora il candidato e propone 5 prove reali su Chrome Android: import esclusivo, duplicato, concorrenza, revisione normale, vite separate. Risultati Android **non ancora disponibili**.

## Limiti
- Non è stata ancora verificata in Android l'implementazione candidata; il codice può contenere difetti runtime.
- Il collaudo HTML usa mondi fittizi minimali e non esegue `engine.load()` originale.
- Non testati: migrazione legacy senza `identity`, errori di quota/storage, crash browser, integrazione ELYRA e retrocompatibilità completa.
- L'importazione è confermata dopo readback; in caso di errore dopo commit ma prima della conferma, la vita può risultare già importata: va gestita come esito incerto, senza ritentare sovrascrivendo.

## Riproduzione
`node test_static.cjs`; caricare `test_atomic_browser.html` su GitHub Pages, aprirlo in Chrome Android e premere «Esegui 5 test», poi copiare il JSON.
